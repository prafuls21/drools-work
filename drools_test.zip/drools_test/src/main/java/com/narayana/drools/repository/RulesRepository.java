package com.narayana.drools.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.narayana.drools.entity.DroolsDrlModel;

public interface RulesRepository extends JpaRepository<DroolsDrlModel, Integer> {

}
