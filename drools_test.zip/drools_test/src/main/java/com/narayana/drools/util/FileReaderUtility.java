package com.narayana.drools.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.stream.Collectors;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;

@Component
public class FileReaderUtility {

	
	public static void readFile(String fileName) {

	    // read a file
	    Resource resource = new ClassPathResource("classpath:rules/discount.drl");

	    // convert inputStream into a byte array
		byte[] dataAsBytes = null;
		try {
			// get inputStream object
			InputStream inputStream = resource.getInputStream();

			dataAsBytes = FileCopyUtils.copyToByteArray(inputStream);
		    // convert the byte array into a String
		    String data = new String(dataAsBytes, StandardCharsets.UTF_8);

		    // print the content
		    System.out.println(data);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	  }
	
	public static  String readFileasString(String fileName)
	{
		String content = "Staring to read";
		try {
			File ruleFile = ResourceUtils.getFile("classpath:RuleAsString.txt");
			content = new String(Files.readAllBytes(ruleFile.toPath()),StandardCharsets.UTF_8);
			
			System.out.println(content);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return content;
		
	}
}	
	
