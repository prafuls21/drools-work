package com.narayana.drools.discount;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.narayana.drools.discount.model.Sale;



@RestController
public class DiscountController {

	//private DiscountService discountService;
	private DiscountService2 discountService2;

	public DiscountController(DiscountService2 service) {
		this.discountService2 = service;
	}

	@PostMapping("/discount")
	private Sale getDiscountPercent(@RequestBody Sale sale) {		
		this.discountService2.applyDiscount(sale);
	    return sale;
	}
	
	@GetMapping("/saveRules")
	private String saveRules() {		
		discountService2.saveRulesInDB();
	    return "Success";
	}
	
	@GetMapping("/reloadRules")
	private String reloadRules() {		
		discountService2.reloadRules();
	    return "Success";
	}
	
	
}