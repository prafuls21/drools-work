package com.narayana.drools.discount;


import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Service;

import com.narayana.drools.discount.model.Sale;
import com.narayana.drools.entity.DroolsDrlModel;
import com.narayana.drools.repository.RulesRepository;
import com.narayana.drools.util.FileReaderUtility;



@Service
public class DiscountService {

	private final KieContainer kieContainer;
	
	RulesRepository repository;

	public DiscountService(KieContainer kieContainer,RulesRepository repository) {
		this.repository =repository;
		this.kieContainer = kieContainer;
	}

	public void applyDiscount(Sale sale) {
		KieSession kieSession = kieContainer.newKieSession();
		kieSession.insert(sale);
		kieSession.fireAllRules();
		kieSession.dispose();
	}
	
	public void saveRulesInDB()
	{
		DroolsDrlModel drlModel = new DroolsDrlModel();
		drlModel.setRule_id(100);
		drlModel.setDroolContent(FileReaderUtility.readFileasString("discount.drl"));
		drlModel.setRuleFileName("discount");
		drlModel.setVersion(1);
		repository.save(drlModel);
		//drlModel.
		//repository.save(null)
	}
}