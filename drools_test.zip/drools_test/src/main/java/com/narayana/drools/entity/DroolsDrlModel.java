package com.narayana.drools.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity(name = "rules_table")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DroolsDrlModel {
	@Id
	@Column(name = "rule_id")
	private Integer rule_id;
	@Column(name = "drl_file_name", nullable = true, length = 500)
	private String ruleFileName;
	@Column(name = "drl_content", nullable = false, length = 25000)
	private String droolContent;
	@Column(name = "version")
	private int version;
	@Column(name = "folder_names", nullable = true, length = 500)
	private String folder_names;
}