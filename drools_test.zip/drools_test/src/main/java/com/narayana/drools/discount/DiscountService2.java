package com.narayana.drools.discount;


import java.sql.DriverManager;
import java.util.List;

import org.kie.api.KieServices;
import org.kie.api.builder.KieBuilder;
import org.kie.api.builder.KieFileSystem;
import org.kie.api.builder.KieRepository;
import org.kie.api.builder.Message;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.KieSessionConfiguration;
import org.kie.api.runtime.conf.TimedRuleExecutionOption;
import org.springframework.stereotype.Service;

import com.narayana.drools.discount.model.Sale;
import com.narayana.drools.entity.DroolsDrlModel;
import com.narayana.drools.repository.RulesRepository;
import com.narayana.drools.util.FileReaderUtility;

import lombok.extern.slf4j.Slf4j;

import java.sql.Connection;
/*import java.sql.DriverManager;
import org.drools.RuleBaseFactory
import org.drools.compiler.PackageBuilder
import org.drools.runtime.rule.RuleContext
import org.drools.template.jdbc.ResultSetGenerator*/





@Service
@Slf4j
public class DiscountService2 {

	private KieContainer kieContainer;
	
	private KieServices  kieServices;
	
	RulesRepository repository;

	public DiscountService2(KieContainer kieContainer,RulesRepository repository) {
		this.kieContainer = kieContainer;
		this.repository=repository;
	}

	public void applyDiscount(Sale sale) {
		KieSession kieSession = kieContainer.newKieSession();
		kieSession.insert(sale);
		kieSession.fireAllRules();
		kieSession.dispose();
	}
	
	
	public void saveRulesInDB()
	{
		DroolsDrlModel drlModel = new DroolsDrlModel();
		drlModel.setRule_id(100);
		drlModel.setDroolContent(FileReaderUtility.readFileasString("discount.drl"));
		drlModel.setRuleFileName("discount.drl");
		drlModel.setVersion(1);
		repository.save(drlModel);
		//drlModel.
		//repository.save(null)
	}
	
	
	
	public void reloadRules() {
	    // TODO Auto-generated method stub
	    List<DroolsDrlModel> droolsDrlModels = repository.findAll();
	    KieContainer kieContainer = loadDroolsSessionContainer(droolsDrlModels);
	    this.kieContainer=kieContainer;
	    KieSession kieSession = this.kieContainer.newKieSession();
	     Thread t1 = new Thread(new Runnable() {
	         public void run() {
	             kieSession.fireUntilHalt();
	           
	         }
	     });

	     t1.start();
	}
	public KieContainer loadDroolsSessionContainer(List<DroolsDrlModel> droolsDrlModels){
	        long startTime = System.currentTimeMillis();
	        if(this.kieServices == null){
	            this.kieServices =  KieServices.Factory.get();
	        }
	       // add following if you are using timer in your rules
	        KieSessionConfiguration ksconf = kieServices.newKieSessionConfiguration();
	        ksconf.setOption(TimedRuleExecutionOption.YES);
	        KieRepository kr = kieServices.getRepository();
	        KieFileSystem kfs = kieServices.newKieFileSystem();
	        
	        for(DroolsDrlModel drlModel:droolsDrlModels){
	             kfs.delete("src/main/resources/"+drlModel.getFolder_names()+"/" + drlModel.getRuleFileName() + ".drl");
	             log.info("Drools DRL was deleted sucessfully "+drlModel.getFolder_names()+"/"+drlModel.getRuleFileName());
	             kfs.write("src/main/resources/" +drlModel.getFolder_names()+"/" + drlModel.getRuleFileName() + ".drl", drlModel.getDroolContent());
	             log.info("Drools DRL was created sucessfully "+drlModel.getFolder_names()+"/"+drlModel.getRuleFileName());
	        }
	        
	        KieBuilder kb = kieServices.newKieBuilder(kfs);
	        
	        kb.buildAll();
	        if (kb.getResults().hasMessages(Message.Level.ERROR)) {
	            throw new RuntimeException("Build Errors:\n" + kb.getResults().toString());
	        }
	        long endTime = System.currentTimeMillis();
	        log.info("Time to build rules : " + (endTime - startTime)  + " ms" );
	        startTime = System.currentTimeMillis();
	        KieContainer kContainer = kieServices.newKieContainer(kr.getDefaultReleaseId());
	        endTime = System.currentTimeMillis();
	        log.info("Time to load container: " + (endTime - startTime)  + " ms" );
	        return kContainer;
	}
	
	
	
	public void fireDBRule()
	{
		 /*String jdbcUrl = "jdbc:mysql://localhost:3306/mydb"
				  Class.forName("com.mysql.jdbc.Driver")
				 Connection conn = DriverManager.getConnection(jdbcUrl, "myuser", "mypass")
				  // build drl with data from database
				  Prepared preparedStmt = conn.prepareStatement("""
				    select rule_cond, rule_cons 
				    from mort_rules""")
				  val resultSet = preparedStmt.executeQuery()
				  val resultSetGenerator = new ResultSetGenerator()
				  val drl = resultSetGenerator.compile(resultSet, 
				    new FileInputStream(template))
				  resultSet.close()
				  preparedStmt.close()
				  conn.close()
				  // build rule base
				  val packageBuilder = new PackageBuilder()
				  packageBuilder.addPackageFromDrl(new StringReader(drl))
				  val ruleBase = RuleBaseFactory.newRuleBase()
				  ruleBase.addPackage(packageBuilder.getPackage())
				  val workingMemory = ruleBase.newStatefulSession()
				  
				  def runRules(facts: Seq[Mortgage]): Unit = {
				    facts.foreach(workingMemory.insert(_))
				    workingMemory.fireAllRules()
				    workingMemory.dispose()
				  }*/
	}
}